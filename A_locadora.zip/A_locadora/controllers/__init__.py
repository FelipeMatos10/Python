from .dashboard_controller import dashboard_bp
from .locadora_controller import locadora_bp
__all__ = ["locadora_bp", "dashboard_bp"]