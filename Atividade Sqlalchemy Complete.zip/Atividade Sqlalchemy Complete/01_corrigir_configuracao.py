import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

pasta = os.path.abspath(os.path.dirname(__file__))

# Configuração da URI do banco de dados e desativação do rastreamento de modificações
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(pasta, "exercicio.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Criação do objeto db associado ao app
db = SQLAlchemy(app)

if __name__ == "__main__":
    print("Configuração OK! Banco:", app.config["SQLALCHEMY_DATABASE_URI"])
    print("Objeto db:", db)